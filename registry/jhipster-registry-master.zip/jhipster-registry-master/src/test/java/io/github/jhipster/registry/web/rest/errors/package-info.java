/**
 * Tests of Spring Data JPA repositories.
 */
package io.github.jhipster.registry.web.rest.errors;
